import { gallery } from '../config/products'
import Art from '../components/Art'
import { Reveal } from '../components/Motion'

export default function Gallery() {
  return (
    <>
      <section className="bg-ink pb-16 pt-40 text-cream">
        <div className="container-x"><h1 className="h-display text-5xl sm:text-6xl">Gallery</h1>
          <p className="mt-4 max-w-lg text-cream/70">A look at our doors, materials, fittings and displays.</p></div>
      </section>
      <section className="py-16">
        <div className="container-x grid grid-cols-2 gap-4 lg:grid-cols-3">
          {gallery.map((g, i) => (
            <Reveal key={g.label} delay={(i % 3) * 0.07} className={i === 0 ? 'col-span-2 lg:col-span-1 lg:row-span-2' : ''}>
              <figure className={`group relative h-full overflow-hidden rounded-xl bg-walnut ${i === 0 ? 'aspect-[4/3] lg:aspect-auto lg:min-h-[28rem]' : 'aspect-square'}`}>
                <Art image={g.image} tone={g.tone} kind={g.kind} alt={g.label} />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/85 p-4 font-display text-xl text-cream">{g.label}</figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  )
}
