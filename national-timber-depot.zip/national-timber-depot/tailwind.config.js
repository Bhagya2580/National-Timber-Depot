export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0807', walnut: '#3B2416', walnutdeep: '#24150C',
        cream: '#F6EFE3', sand: '#E8DCC6', gold: '#B8924A', goldlt: '#DDBB72',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
