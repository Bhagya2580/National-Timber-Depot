// Categories are fixed here. Products and gallery are edited from the /admin page
// (or directly in src/content/products.json and gallery.json).
import productData from '../content/products.json'
import galleryData from '../content/gallery.json'
export const categories = [
  { id: 'wooden-doors', name: 'Wooden Doors', icon: 'DoorOpen', tone: 0, kind: 'door' },
  { id: 'wpc-doors', name: 'WPC Doors', icon: 'DoorClosed', tone: 1, kind: 'door' },
  { id: 'pvc-doors', name: 'PVC Doors', icon: 'DoorClosed', tone: 2, kind: 'door' },
  { id: 'plywood', name: 'Plywood', icon: 'Layers', tone: 3, kind: 'sheet' },
  { id: 'laminates', name: 'Laminates', icon: 'Palette', tone: 4, kind: 'sheet' },
  { id: 'door-handles', name: 'Door Handles', icon: 'Grip', tone: 5, kind: 'metal' },
  { id: 'locks-hinges', name: 'Locks and Hinges', icon: 'Lock', tone: 5, kind: 'metal' },
  { id: 'door-accessories', name: 'Door Accessories', icon: 'Wrench', tone: 5, kind: 'metal' },
  { id: 'interior-hardware', name: 'Interior Hardware', icon: 'Armchair', tone: 5, kind: 'metal' },
  { id: 'other-fittings', name: 'Other Fittings', icon: 'Package', tone: 3, kind: 'sheet' },
]

export const products = productData.items.map((p) => ({ ...p, image: p.image || undefined }))
export const gallery = galleryData.items.map((g) => ({ ...g, image: g.image || undefined }))
