# National Timber Depot - Website

React + Vite + Tailwind CSS + Framer Motion + Lucide icons.

## 1. Preview locally (first time)
1. Install Node.js 18 or newer (LTS) from https://nodejs.org
2. Unzip this folder, open a terminal inside it.
3. Run:
   ```
   npm install
   npm run dev
   ```
4. Open http://localhost:5173 in your browser. Edits to files update the page instantly.

Next time, only `npm run dev` is needed. Internet is needed the first time (to install packages and load Google Fonts).

**Production preview:** `npm run build` then `npm run preview`.

## 2. Folder structure
```
national-timber-depot/
  index.html            page shell, SEO title/description
  package.json          dependencies and scripts
  netlify.toml          Netlify build settings
  tailwind.config.js    brand colours and fonts
  public/images/        put your photos here
  src/
    main.jsx, App.jsx   entry and page switching
    index.css           global styles
    config/site.js      SHOP DETAILS (name, phone, WhatsApp, address, hours, maps, social)
    config/products.js  categories (fixed list)
    content/products.json, gallery.json   products and gallery (edited by /admin)
    components/         Navbar, Footer, Loader, ProductCard, EnquiryForm, Art, Motion, WhatsApp
    pages/              Home, About, Products, Gallery, Contact
```

## 3. Replace shop details
Open `src/config/site.js`. Replace everything marked PLACEHOLDER. WhatsApp number = country code + number, digits only (e.g. `919876543210`).
Google Maps: Maps > your shop > Share > Embed a map > copy only the URL inside `src="..."` into `mapsEmbed`.
About page text with [brackets] is in `src/pages/About.jsx`.

## 4. Replace images and products
Easiest: use the /admin page (section 8). Manual way: copy photos into `public/images/` and set `"image": "/images/door1.jpg"` in `src/content/products.json` or `gallery.json`.
Logo: put `logo.png` in `public/` and set `logo: '/logo.png'` in `site.js`.
Until a photo is added, a wood-texture panel shows (no broken images).

## 5. Deploy free on Netlify
- Easiest: `npm run build`, then drag the `dist` folder onto https://app.netlify.com/drop
- Or push to GitHub and import it in Netlify (settings are already in `netlify.toml`).

## 6. Custom domain
Buy a domain, then Netlify > Site configuration > Domain management > Add a domain. Use Netlify DNS or add the DNS records Netlify shows. HTTPS is automatic.

## 7. Enquiry form and backend
The form opens WhatsApp with the customer's message, so no backend is needed. To also receive email, create a free Formspree form and paste its URL into `formEndpoint` in `site.js`.

## Troubleshooting
- `npm: command not found` - install Node.js, then reopen the terminal.
- Blank page or errors - make sure you ran `npm install` and use Node 18+.
- Port busy - Vite will suggest another port; open the address it prints.

## 8. Admin panel (edit product names and upload photos, free)
The site includes an admin page at `https://YOUR-SITE.netlify.app/admin`. After setup, the owner logs in, edits product names and descriptions, adds or removes products, uploads photos, and presses Publish. The site rebuilds and updates itself in about a minute.

One-time setup (about 15 minutes):
1. Create a free GitHub account and a new repository. Upload this whole project to it.
2. Open `public/admin/config.yml` and replace `YOUR_GITHUB_USERNAME/YOUR_REPO_NAME` with your repository (for example `shopname/ntd-website`).
3. In Netlify: Add new site > Import from GitHub > pick the repository. Build command `npm run build`, publish directory `dist`.
4. Create a GitHub OAuth App: GitHub > Settings > Developer settings > OAuth Apps > New. Homepage URL = your Netlify site URL. Authorization callback URL = `https://api.netlify.com/auth/done`. Copy the Client ID and generate a Client Secret.
5. In Netlify: Site configuration > Access & security > OAuth > Install provider > GitHub, then paste the Client ID and Secret.
6. Open `/admin` on your site and log in with GitHub. Anyone who edits needs a GitHub account with access to the repository (add the owner under repository Settings > Collaborators).
7. If you use a custom domain, add `site_domain: yourdomain.com` under `backend:` in `config.yml`.

Notes: the admin does not work on `localhost` or in a plain drag-and-drop Netlify deploy, because it saves changes to GitHub. Photos should be under about 300 KB (resize at squoosh.app before uploading). Shop phone, WhatsApp, address and hours are still edited in `src/config/site.js`.
