import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle2 } from 'lucide-react'
import { site, waLink } from '../config/site'

const validate = (v) => {
  const e = {}
  if (v.name.trim().length < 2) e.name = 'Please enter your name.'
  if (!/^\d{10,13}$/.test(v.phone.replace(/[\s+\-()]/g, ''))) e.phone = 'Enter a valid phone number (10 digits or more).'
  if (v.message.trim().length < 5) e.message = 'Please tell us what you need (at least 5 characters).'
  return e
}

export default function EnquiryForm({ dark = false }) {
  const [v, setV] = useState({ name: '', phone: '', message: '' })
  const [err, setErr] = useState({})
  const [sent, setSent] = useState(false)
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    const errors = validate(v)
    setErr(errors)
    if (Object.keys(errors).length) return
    const text = `Hello ${site.name}, my name is ${v.name.trim()} (phone: ${v.phone.trim()}). ${v.message.trim()}`
    window.open(waLink(text), '_blank', 'noopener')
    if (site.formEndpoint) {
      try { await fetch(site.formEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(v) }) } catch { /* WhatsApp still opened */ }
    }
    setSent(true); setV({ name: '', phone: '', message: '' })
  }

  const input = `w-full rounded-lg border px-4 py-3 text-sm outline-none transition focus:border-gold focus:ring-2 focus:ring-gold/30 ${dark ? 'border-cream/20 bg-cream/5 text-cream placeholder:text-cream/40' : 'border-walnut/20 bg-white text-walnut'}`
  const label = `mb-1.5 block text-sm font-medium ${dark ? 'text-cream/80' : 'text-walnut'}`
  const Err = ({ k }) => err[k] ? <p role="alert" className="mt-1 text-xs text-red-400">{err[k]}</p> : null

  return (
    <AnimatePresence mode="wait">
      {sent ? (
        <motion.div key="ok" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          className={`rounded-xl p-8 text-center ${dark ? 'bg-cream/5 text-cream' : 'bg-white text-walnut ring-1 ring-walnut/10'}`} role="status">
          <CheckCircle2 className="mx-auto h-12 w-12 text-gold" />
          <p className="h-display mt-4 text-3xl">Enquiry ready to send</p>
          <p className="mt-2 text-sm opacity-75">WhatsApp has opened with your message. Press send there and we will reply soon.</p>
          <button onClick={() => setSent(false)} className="mt-6 text-sm font-semibold text-gold underline underline-offset-4">Send another enquiry</button>
        </motion.div>
      ) : (
        <motion.form key="form" onSubmit={submit} noValidate exit={{ opacity: 0 }} className="space-y-4">
          <div><label className={label} htmlFor="f-name">Name</label><input id="f-name" className={input} value={v.name} onChange={set('name')} autoComplete="name" /><Err k="name" /></div>
          <div><label className={label} htmlFor="f-phone">Phone number</label><input id="f-phone" className={input} value={v.phone} onChange={set('phone')} inputMode="tel" autoComplete="tel" /><Err k="phone" /></div>
          <div><label className={label} htmlFor="f-msg">Message</label><textarea id="f-msg" rows={4} className={input} value={v.message} onChange={set('message')} placeholder="Which products do you need?" /><Err k="message" /></div>
          <button type="submit" className="btn-gold w-full">Send enquiry</button>
        </motion.form>
      )}
    </AnimatePresence>
  )
}
