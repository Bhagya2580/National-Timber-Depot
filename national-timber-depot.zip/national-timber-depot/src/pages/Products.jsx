import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { categories, products } from '../config/products'
import ProductCard from '../components/ProductCard'

export default function Products() {
  const [active, setActive] = useState('all')
  const list = active === 'all' ? products : products.filter((p) => p.category === active)
  const chips = [{ id: 'all', name: 'All' }, ...categories]
  return (
    <>
      <section className="bg-ink pb-16 pt-40 text-cream">
        <div className="container-x">
          <h1 className="h-display text-5xl sm:text-6xl">Our products</h1>
          <p className="mt-4 max-w-lg text-cream/70">Pick a category, then tap Enquire on WhatsApp for details on any product.</p>
        </div>
      </section>
      <section className="py-16">
        <div className="container-x">
          <div className="-mx-5 mb-10 flex gap-2 overflow-x-auto px-5 pb-2 sm:mx-0 sm:flex-wrap sm:px-0" role="tablist" aria-label="Product categories">
            {chips.map((c) => (
              <button key={c.id} role="tab" aria-selected={active === c.id} onClick={() => setActive(c.id)}
                className={`relative shrink-0 rounded-full px-5 py-2 text-sm font-medium transition ${active === c.id ? 'text-ink' : 'bg-white text-walnut ring-1 ring-walnut/15 hover:ring-gold'}`}>
                {active === c.id && <motion.span layoutId="chip" className="absolute inset-0 rounded-full bg-gold" />}
                <span className="relative">{c.name}</span>
              </button>
            ))}
          </div>
          <motion.div layout className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">{list.map((p) => <ProductCard key={p.name} product={p} />)}</AnimatePresence>
          </motion.div>
        </div>
      </section>
    </>
  )
}
