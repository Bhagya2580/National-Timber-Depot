import { motion } from 'framer-motion'
import { productMsg, waLink } from '../config/site'
import { categories } from '../config/products'
import Art from './Art'
import { WhatsAppIcon } from './WhatsApp'

export default function ProductCard({ product }) {
  const cat = categories.find((c) => c.id === product.category)
  return (
    <motion.article layout initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.35 }} whileHover={{ y: -6 }}
      className="group flex flex-col overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-walnut/10 transition-shadow hover:shadow-xl hover:shadow-walnut/15">
      <div className="aspect-[4/3] overflow-hidden bg-walnut">
        <Art image={product.image} tone={cat.tone} kind={cat.kind} icon={cat.icon} alt={product.name} />
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="text-xs font-medium text-gold">{cat.name}</p>
        <h3 className="h-display mt-1 text-2xl text-walnut">{product.name}</h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-walnut/70">{product.description}</p>
        <a href={waLink(productMsg(product.name))} target="_blank" rel="noreferrer"
          className="mt-5 inline-flex items-center justify-center gap-2 rounded-full bg-walnut px-5 py-2.5 text-sm font-semibold text-cream transition hover:bg-gold hover:text-ink active:scale-95">
          <WhatsAppIcon className="h-4 w-4" /> Enquire on WhatsApp
        </a>
      </div>
    </motion.article>
  )
}
