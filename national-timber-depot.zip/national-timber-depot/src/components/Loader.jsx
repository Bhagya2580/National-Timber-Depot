import { motion } from 'framer-motion'
import { site } from '../config/site'
export default function Loader() {
  return (
    <motion.div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink"
      exit={{ y: '-100%' }} transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}>
      <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}
        className="h-display text-3xl text-cream sm:text-5xl">{site.name}</motion.p>
      <div className="mt-6 h-px w-48 overflow-hidden bg-cream/15">
        <motion.div className="h-full bg-goldlt" initial={{ x: '-100%' }} animate={{ x: 0 }} transition={{ duration: 1.3, ease: 'easeInOut' }} />
      </div>
    </motion.div>
  )
}
