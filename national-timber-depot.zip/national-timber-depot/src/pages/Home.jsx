import { motion, useScroll, useTransform } from 'framer-motion'
import { ArrowRight, BadgeCheck, Boxes, Handshake, HeartHandshake, Wallet } from 'lucide-react'
import { useRef } from 'react'
import { site } from '../config/site'
import { categories, products } from '../config/products'
import Art from '../components/Art'
import ProductCard from '../components/ProductCard'
import EnquiryForm from '../components/EnquiryForm'
import { Counter, Reveal, SectionTitle } from '../components/Motion'

export const why = [
  [BadgeCheck, 'Quality Products', 'Doors, plywood and hardware selected for lasting performance.'],
  [Boxes, 'Wide Product Selection', 'Everything for doors and interiors, available under one roof.'],
  [Handshake, 'Reliable Service', 'Clear communication and dependable support from enquiry to purchase.'],
  [HeartHandshake, 'Professional Assistance', 'Helpful guidance to choose the right material for your space.'],
  [Wallet, 'Value for Money', 'Good materials at fair value. Ask for a quote on WhatsApp.'],
]

function Hero() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '25%'])
  const ease = [0.22, 1, 0.36, 1]
  return (
    <section ref={ref} className="relative flex min-h-screen items-center overflow-hidden bg-ink">
      <motion.div style={{ y }} className="absolute inset-0 opacity-70">
        <Art tone={0} kind="door" icon="DoorOpen" alt="" className="!scale-110" />
      </motion.div>
      <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/30" />
      <div className="container-x relative pb-16 pt-32">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6, duration: 1 }}
          className="font-display text-2xl text-goldlt">{site.name}</motion.p>
        <h1 className="h-display mt-4 max-w-3xl text-5xl text-cream sm:text-7xl lg:text-8xl">
          {site.tagline.split(' ').map((w, i) => (
            <span key={i} className="mr-[0.25em] inline-block overflow-hidden align-bottom">
              <motion.span className="inline-block" initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ delay: 1.7 + i * 0.12, duration: 0.9, ease }}>{w}</motion.span>
            </span>
          ))}
        </h1>
        <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2.4, duration: 0.8 }}
          className="mt-6 max-w-xl text-lg leading-relaxed text-cream/75">{site.subtitle}</motion.p>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2.6, duration: 0.8 }}
          className="mt-9 flex flex-wrap gap-4">
          <a href="#/products" className="btn-gold">Explore Products <ArrowRight className="h-4 w-4" /></a>
          <a href="#/contact" className="btn-line">Contact Us</a>
        </motion.div>
      </div>
    </section>
  )
}

export default function Home() {
  const stats = [
    { value: categories.length, label: 'Product categories' },
    { value: products.length, label: 'Products listed' },
    ...site.extraStats,
  ]
  return (
    <>
      <Hero />
      <section className="py-24">
        <div className="container-x">
          <SectionTitle title="Everything for your doors and interiors" text="Browse our main categories, then enquire on WhatsApp about any product." />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {categories.slice(0, 6).map((c, i) => (
              <Reveal key={c.id} delay={(i % 3) * 0.08}>
                <a href="#/products" className="group relative block aspect-[5/4] overflow-hidden rounded-xl bg-walnut">
                  <Art tone={c.tone} kind={c.kind} icon={c.icon} alt={c.name} />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-transparent" />
                  <div className="absolute inset-x-0 bottom-0 flex items-center justify-between p-5 text-cream">
                    <span className="h-display text-2xl">{c.name}</span>
                    <ArrowRight className="h-5 w-5 text-goldlt transition group-hover:translate-x-1" />
                  </div>
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-ink py-24 text-cream">
        <div className="container-x">
          <SectionTitle light title="Why choose us" />
          <div className="grid gap-px overflow-hidden rounded-xl bg-cream/10 sm:grid-cols-2 lg:grid-cols-3">
            {why.map(([Icon, t, d], i) => (
              <Reveal key={t} delay={i * 0.06} className="bg-ink p-8 transition hover:bg-walnutdeep">
                <Icon className="h-8 w-8 text-goldlt" strokeWidth={1.3} />
                <h3 className="h-display mt-5 text-2xl">{t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-cream/65">{d}</p>
              </Reveal>
            ))}
          </div>
          <div className="mt-16 flex flex-wrap justify-center gap-x-20 gap-y-8">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <p className="h-display text-6xl text-goldlt"><Counter to={s.value} suffix={s.suffix} /></p>
                <p className="mt-1 text-sm text-cream/60">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-x">
          <SectionTitle title="Product highlights" text="A few of the products customers ask about most. Prices on request." />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[products[0], products[2], products[6], products[8], products[10], products[12]].map((p) => <ProductCard key={p.name} product={p} />)}
          </div>
          <div className="mt-10 text-center"><a href="#/products" className="btn-gold">View all products</a></div>
        </div>
      </section>

      <section className="bg-walnut py-24">
        <div className="container-x grid gap-12 lg:grid-cols-2">
          <Reveal>
            <h2 className="h-display text-4xl text-cream sm:text-5xl">Tell us what you need</h2>
            <p className="mt-4 max-w-md leading-relaxed text-cream/70">Send your requirement and we will continue the conversation on WhatsApp with details and guidance.</p>
          </Reveal>
          <Reveal delay={0.1}><EnquiryForm dark /></Reveal>
        </div>
      </section>
    </>
  )
}
