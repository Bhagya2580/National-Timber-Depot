import { site } from '../config/site'
import Art from '../components/Art'
import { Reveal, SectionTitle } from '../components/Motion'

const blocks = [
  ['Business overview', `${site.name} supplies doors, plywood, laminates and hardware for homes, offices and interior projects. [Add the owner's own introduction here: location, years in business, who you serve.]`],
  ['Commitment to quality', 'We choose materials that look good and last. [Add brands, grades or certifications you actually stock.]'],
  ['Product variety', 'From wooden, WPC and PVC doors to handles, locks, hinges and interior fittings, customers can find what they need in one place.'],
  ['Customer satisfaction', 'We aim to be easy to reach and helpful at every step. Ask us anything on WhatsApp. [Add real customer testimonials when available.]'],
]

export default function About() {
  return (
    <>
      <section className="bg-ink pb-20 pt-40 text-cream">
        <div className="container-x grid items-center gap-12 lg:grid-cols-2">
          <Reveal>
            <h1 className="h-display text-5xl sm:text-6xl">About {site.name}</h1>
            <p className="mt-6 max-w-lg leading-relaxed text-cream/70">Your trusted destination for premium doors, plywood and hardware.</p>
            <div className="mt-6 h-px w-16 bg-gold" />
          </Reveal>
          <Reveal delay={0.1}><div className="group aspect-[4/3] overflow-hidden rounded-xl"><Art tone={1} kind="door" icon="DoorOpen" alt="Showroom" /></div></Reveal>
        </div>
      </section>
      <section className="py-24">
        <div className="container-x">
          <SectionTitle title="What we stand for" />
          <div className="grid gap-x-16 gap-y-12 md:grid-cols-2">
            {blocks.map(([t, d], i) => (
              <Reveal key={t} delay={(i % 2) * 0.08}>
                <h3 className="h-display text-3xl text-walnut">{t}</h3>
                <p className="mt-3 leading-relaxed text-walnut/75">{d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
