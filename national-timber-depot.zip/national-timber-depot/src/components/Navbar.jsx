import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { site } from '../config/site'

export const links = [['Home', '/'], ['About', '/about'], ['Products', '/products'], ['Gallery', '/gallery'], ['Contact', '/contact']]

export default function Navbar({ route }) {
  const [open, setOpen] = useState(false)
  const [solid, setSolid] = useState(false)
  useEffect(() => {
    const f = () => setSolid(window.scrollY > 40)
    f(); window.addEventListener('scroll', f, { passive: true })
    return () => window.removeEventListener('scroll', f)
  }, [])
  useEffect(() => setOpen(false), [route])

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition duration-500 ${solid || open ? 'bg-ink/90 backdrop-blur-md shadow-lg shadow-black/20' : 'bg-transparent'}`}>
      <nav className="container-x flex h-[72px] items-center justify-between" aria-label="Main">
        <a href="#/" className="flex items-center gap-3 text-cream">
          {site.logo
            ? <img src={site.logo} alt={site.name} className="h-10 w-auto" />
            : <span className="flex h-10 w-10 items-center justify-center rounded-md border border-goldlt/60 font-display text-xl text-goldlt">N</span>}
          <span className="h-display text-xl sm:text-2xl">{site.name}</span>
        </a>
        <ul className="hidden items-center gap-8 md:flex">
          {links.map(([label, path]) => (
            <li key={path}>
              <a href={`#${path}`} className={`group relative py-2 text-sm font-medium transition ${route === path ? 'text-goldlt' : 'text-cream/80 hover:text-cream'}`}>
                {label}
                {route === path && <motion.span layoutId="nav-underline" className="absolute inset-x-0 -bottom-0.5 h-px bg-goldlt" />}
              </a>
            </li>
          ))}
        </ul>
        <button className="p-2 text-cream md:hidden" onClick={() => setOpen(!open)} aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open}>
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.ul initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-cream/10 md:hidden">
            {links.map(([label, path], i) => (
              <motion.li key={path} initial={{ x: -16, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.05 * i }}>
                <a href={`#${path}`} className={`block px-6 py-4 text-lg font-display ${route === path ? 'text-goldlt' : 'text-cream'}`}>{label}</a>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </header>
  )
}
