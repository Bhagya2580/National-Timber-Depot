import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { site, waLink } from './config/site'
import Loader from './components/Loader'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import { WhatsAppIcon } from './components/WhatsApp'
import Home from './pages/Home'
import About from './pages/About'
import Products from './pages/Products'
import Gallery from './pages/Gallery'
import Contact from './pages/Contact'

const pages = {
  '/': [Home, `${site.name} | Premium Doors, Plywood & Hardware`, site.description],
  '/about': [About, `About Us | ${site.name}`, `Learn about ${site.name}: quality doors, plywood and hardware.`],
  '/products': [Products, `Products | ${site.name}`, 'Wooden, WPC and PVC doors, plywood, laminates, handles, locks, hinges and fittings.'],
  '/gallery': [Gallery, `Gallery | ${site.name}`, 'Photos of doors, plywood, hardware and interiors.'],
  '/contact': [Contact, `Contact | ${site.name}`, 'Address, phone, business hours and WhatsApp enquiries.'],
}
const getRoute = () => { const r = window.location.hash.replace('#', '') || '/'; return pages[r] ? r : '/' }

export default function App() {
  const [route, setRoute] = useState(getRoute())
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    const on = () => { setRoute(getRoute()); window.scrollTo({ top: 0, behavior: 'instant' }) }
    window.addEventListener('hashchange', on)
    const t = setTimeout(() => setLoading(false), 1500)
    return () => { window.removeEventListener('hashchange', on); clearTimeout(t) }
  }, [])
  const [Page, title, desc] = pages[route]
  useEffect(() => {
    document.title = title
    document.querySelector('meta[name="description"]')?.setAttribute('content', desc)
  }, [title, desc])

  return (
    <>
      <AnimatePresence>{loading && <Loader />}</AnimatePresence>
      <Navbar route={route} />
      <AnimatePresence mode="wait">
        <motion.main key={route} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
          <Page />
        </motion.main>
      </AnimatePresence>
      <Footer />
      <a href={waLink(`Hello ${site.name}, I would like to know more.`)} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"
        className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl transition hover:scale-110 active:scale-95">
        <WhatsAppIcon className="h-7 w-7" />
      </a>
    </>
  )
}
