import { motion, useInView, useReducedMotion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

export function Reveal({ children, delay = 0, className = '' }) {
  const reduce = useReducedMotion()
  return (
    <motion.div className={className} initial={reduce ? false : { opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  )
}

export function Counter({ to, suffix = '' }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true })
  const [n, setN] = useState(0)
  useEffect(() => {
    if (!inView) return
    let raf, start
    const step = (t) => {
      start ??= t
      const k = Math.min((t - start) / 1400, 1)
      setN(Math.round(to * (1 - Math.pow(1 - k, 3))))
      if (k < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [inView, to])
  return <span ref={ref}>{n}{suffix}</span>
}

export function SectionTitle({ title, text, light }) {
  return (
    <Reveal className="mb-12 max-w-2xl">
      <h2 className={`h-display text-4xl sm:text-5xl ${light ? 'text-cream' : 'text-walnut'}`}>{title}</h2>
      {text && <p className={`mt-4 text-base leading-relaxed ${light ? 'text-cream/70' : 'text-walnut/70'}`}>{text}</p>}
      <div className="mt-6 h-px w-16 bg-gold" />
    </Reveal>
  )
}
