import { Clock, MapPin, Phone } from 'lucide-react'
import { site, waLink } from '../config/site'
import EnquiryForm from '../components/EnquiryForm'
import { Reveal } from '../components/Motion'
import { WhatsAppIcon } from '../components/WhatsApp'

export default function Contact() {
  return (
    <>
      <section className="bg-ink pb-16 pt-40 text-cream">
        <div className="container-x"><h1 className="h-display text-5xl sm:text-6xl">Contact us</h1>
          <p className="mt-4 max-w-lg text-cream/70">Visit the shop, call, or message us on WhatsApp.</p></div>
      </section>
      <section className="py-16">
        <div className="container-x grid gap-12 lg:grid-cols-2">
          <Reveal className="space-y-8">
            <div className="flex gap-4"><MapPin className="mt-1 h-6 w-6 shrink-0 text-gold" /><div><p className="h-display text-2xl">Shop address</p><p className="text-walnut/75">{site.address.join(', ')}</p></div></div>
            <div className="flex gap-4"><Phone className="mt-1 h-6 w-6 shrink-0 text-gold" /><div><p className="h-display text-2xl">Phone</p><a href={`tel:${site.phone.replace(/\s/g, '')}`} className="text-walnut/75 hover:text-gold">{site.phone}</a></div></div>
            <div className="flex gap-4"><Clock className="mt-1 h-6 w-6 shrink-0 text-gold" /><div><p className="h-display text-2xl">Business hours</p>
              {site.hours.map((h) => <p key={h.days} className="text-walnut/75">{h.days}: {h.time}</p>)}</div></div>
            <a href={waLink(`Hello ${site.name}, I would like to know more.`)} target="_blank" rel="noreferrer" className="btn-gold"><WhatsAppIcon className="h-5 w-5" /> Chat on WhatsApp</a>
            <div className="aspect-video overflow-hidden rounded-xl bg-sand ring-1 ring-walnut/10">
              {site.mapsEmbed
                ? <iframe title="Shop location" src={site.mapsEmbed} className="h-full w-full border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
                : <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center text-sm text-walnut/70"><MapPin className="h-8 w-8 text-gold" />Google Maps placeholder. Add the embed link in src/config/site.js (mapsEmbed).</div>}
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="rounded-xl bg-white p-6 ring-1 ring-walnut/10 sm:p-8">
              <h2 className="h-display mb-6 text-3xl text-walnut">Send an enquiry</h2>
              <EnquiryForm />
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
