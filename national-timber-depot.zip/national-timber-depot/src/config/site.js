// ============================================================
//  EDIT THIS FILE to change shop details. Everything marked
//  PLACEHOLDER must be replaced with the shop owner's real info.
// ============================================================
export const site = {
  name: 'National Timber Depot',
  tagline: 'Quality That Builds Your Space.',
  subtitle: 'Your Trusted Destination for Premium Doors, Plywood & Hardware.',
  description: 'Wooden, WPC and PVC doors, plywood, laminates, hardware and interior fittings.',
  logo: '', // e.g. '/logo.png' (put the file in /public). Empty = text logo.

  phone: '+91 00000 00000',          // PLACEHOLDER
  whatsapp: '910000000000',          // PLACEHOLDER: country code + number, digits only (e.g. 919876543210)
  email: 'info@example.com',         // PLACEHOLDER
  address: ['[Shop address line 1]', '[Area, City, State - PIN]'], // PLACEHOLDER
  hours: [                           // PLACEHOLDER
    { days: 'Monday - Saturday', time: '[00:00 AM - 00:00 PM]' },
    { days: 'Sunday', time: '[Open / Closed]' },
  ],
  // Google Maps: open your shop in Google Maps > Share > Embed a map > copy ONLY the src="..." URL
  mapsEmbed: '',
  mapsLink: '',                      // optional "Open in Google Maps" link
  social: { instagram: 'https://instagram.com/', facebook: 'https://facebook.com/' }, // PLACEHOLDER

  // Optional: paste a Formspree/Getform endpoint to also receive enquiries by email. Leave '' for WhatsApp only.
  formEndpoint: '',

  // Optional extra counters, e.g. { value: 500, suffix: '+', label: 'Happy customers' }. Add only real numbers.
  extraStats: [],
}

export const waLink = (text) => `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(text)}`
export const productMsg = (name) =>
  `Hello ${site.name}, I am interested in ${name}. Please share the details.`
