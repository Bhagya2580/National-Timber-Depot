import { Facebook, Instagram, MapPin, Phone } from 'lucide-react'
import { site, waLink } from '../config/site'
import { categories } from '../config/products'
import { links } from './Navbar'
import { WhatsAppIcon } from './WhatsApp'

export default function Footer() {
  return (
    <footer className="bg-ink text-cream/70">
      <div className="container-x grid gap-10 py-16 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="h-display text-2xl text-cream">{site.name}</p>
          <p className="mt-3 text-sm leading-relaxed">{site.description}</p>
          <div className="mt-5 flex gap-3 text-cream">
            <a href={waLink(`Hello ${site.name}`)} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="rounded-full border border-cream/20 p-2.5 transition hover:border-goldlt hover:text-goldlt"><WhatsAppIcon className="h-4 w-4" /></a>
            <a href={site.social.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="rounded-full border border-cream/20 p-2.5 transition hover:border-goldlt hover:text-goldlt"><Instagram className="h-4 w-4" /></a>
            <a href={site.social.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="rounded-full border border-cream/20 p-2.5 transition hover:border-goldlt hover:text-goldlt"><Facebook className="h-4 w-4" /></a>
          </div>
        </div>
        <div>
          <p className="mb-4 font-display text-lg text-cream">Quick links</p>
          <ul className="space-y-2 text-sm">{links.map(([l, p]) => <li key={p}><a className="transition hover:text-goldlt" href={`#${p}`}>{l}</a></li>)}</ul>
        </div>
        <div>
          <p className="mb-4 font-display text-lg text-cream">Products</p>
          <ul className="space-y-2 text-sm">{categories.slice(0, 6).map((c) => <li key={c.id}><a className="transition hover:text-goldlt" href="#/products">{c.name}</a></li>)}</ul>
        </div>
        <div>
          <p className="mb-4 font-display text-lg text-cream">Contact</p>
          <ul className="space-y-3 text-sm">
            <li className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold" />{site.address.join(', ')}</li>
            <li className="flex gap-2"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold" />{site.phone}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-cream/10 py-5 text-center text-xs">
        © {new Date().getFullYear()} {site.name}. All rights reserved.
      </div>
    </footer>
  )
}
