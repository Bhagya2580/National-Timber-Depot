import { useState } from 'react'
import * as Icons from 'lucide-react'

// Procedural wood/metal texture used until a real photo is supplied via `image`.
const tones = [
  ['#5a3520', '#3b2416'], ['#7a5232', '#4d311d'], ['#8d6a45', '#5b3f26'],
  ['#c49a62', '#98723f'], ['#2c1d14', '#1a110b'], ['#2a2a2c', '#111112'],
]
export default function Art({ image, tone = 0, kind = 'sheet', icon = 'Package', alt = '', className = '' }) {
  const [failed, setFailed] = useState(false)
  if (image && !failed)
    return <img src={image} alt={alt} loading="lazy" onError={() => setFailed(true)}
      className={`h-full w-full object-cover transition duration-700 group-hover:scale-110 ${className}`} />
  const [a, b] = tones[tone % tones.length]
  const Icon = Icons[icon] || Icons.Package
  const grain = kind === 'metal'
    ? `linear-gradient(135deg, ${a}, ${b}), repeating-linear-gradient(90deg,rgba(255,255,255,.05) 0 1px,transparent 1px 6px)`
    : `repeating-linear-gradient(92deg, rgba(0,0,0,.18) 0 2px, transparent 2px 9px), repeating-linear-gradient(88deg, rgba(255,255,255,.06) 0 1px, transparent 1px 13px), linear-gradient(160deg, ${a}, ${b})`
  return (
    <div role="img" aria-label={alt} className={`relative h-full w-full overflow-hidden transition duration-700 group-hover:scale-110 ${className}`} style={{ background: grain }}>
      {kind === 'door' && (
        <div className="absolute inset-[14%] grid grid-cols-2 gap-[6%]">
          {[0, 1, 2, 3].map((i) => <div key={i} className="rounded-sm border border-black/25 shadow-[inset_0_0_14px_rgba(0,0,0,.35),0_1px_0_rgba(255,255,255,.12)]" />)}
        </div>
      )}
      {kind === 'sheet' && <div className="absolute inset-x-0 bottom-0 h-3 bg-gradient-to-b from-white/10 to-black/30" />}
      <Icon className="absolute left-1/2 top-1/2 h-9 w-9 -translate-x-1/2 -translate-y-1/2 text-goldlt/80 drop-shadow" strokeWidth={1.2} />
    </div>
  )
}
